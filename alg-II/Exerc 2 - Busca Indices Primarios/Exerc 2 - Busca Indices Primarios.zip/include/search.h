#ifndef SEARCH_H
#define SEARCH_H

#include <cabecalho.h>

long search(int id, INDEX* noCabeca);
void lerRegistros(FILE* file,long byteOffset);


#endif //SEARCH_H