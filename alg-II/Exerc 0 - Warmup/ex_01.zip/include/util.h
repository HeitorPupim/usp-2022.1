#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>

//função que lê uma linha e aloca dinamicamente na memória
char* readline(char parada);

#endif //UTIL_H