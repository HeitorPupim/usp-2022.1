
public class Mouse implements Dispositivo{


	public void ligar() {
		System.out.println("Ligando Mouse");
		
	}

	
	public void desligar() {
		System.out.println("Desligando Mouse");
		
	}


	public void checarStatus() {
		System.out.println("Checando Status do Mouse");
		
	}


	public void calibrar() {
		System.out.println("Calibrando Mouse");
	}

}
