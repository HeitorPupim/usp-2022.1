
public class Teclado implements Dispositivo{

	public void ligar() {
		System.out.println("Ligando Teclado");
		
	}

	
	public void desligar() {
		System.out.println("Desligando Teclado");
		
	}


	public void checarStatus() {
		System.out.println("Checando Status do Teclado");
		
	}


	public void calibrar() {
		System.out.println("Calibrando teclado");
	}

}
