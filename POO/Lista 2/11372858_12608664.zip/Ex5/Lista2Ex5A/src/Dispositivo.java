public interface Dispositivo {

	public void ligar();
	public void desligar();
	public void checarStatus();
	public void calibrar();
	
}
