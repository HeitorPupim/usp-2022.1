abstract class Dispositivo {

	public void ligarDispositivo(){
		System.out.println("Dispositivo ligou");
	}
	
}
