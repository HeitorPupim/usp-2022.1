public class Mouse extends Dispositivo{

	public void ligarDispositivo() {
		System.out.println("Mouse ligou e ancendeu 1238129 led");
	}
	
}
