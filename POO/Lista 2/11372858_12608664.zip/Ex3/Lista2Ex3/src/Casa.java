
public class Casa extends Predio{

	
	public Casa(int qtdePessoas) {
		super(qtdePessoas);
	}

	
	public Casa(int qtdePessoas, int qtdeAndares) {
		super(qtdePessoas, qtdeAndares);
	}
	
	

}
