
public class Escola extends Predio{

	public Escola(int qtdePessoas) {
		super(qtdePessoas);
	}

	
	public Escola(int qtdePessoas, int qtdeAndares) {
		super(qtdePessoas, qtdeAndares);
	}

}
