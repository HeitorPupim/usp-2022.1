public interface PegadaDeCarbono {
	
	int getPegadaDeCarbono();
}
