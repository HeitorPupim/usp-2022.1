public interface SistemaConfig {
    
    void abreSistema();
}
