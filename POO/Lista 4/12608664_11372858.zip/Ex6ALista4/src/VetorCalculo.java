public interface VetorCalculo {
    public abstract Integer[] PerformCalculus(Vetor vetor);
}
