public abstract class Divida{
   double valor;
   public abstract String getDescricao();
   public abstract double getValor();
}