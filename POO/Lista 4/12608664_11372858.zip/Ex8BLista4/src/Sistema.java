public abstract class Sistema {
    
    String usuario;
    String senha;

    abstract void LoguinSistema();
}
