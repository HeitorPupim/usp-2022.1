public class VetorInterseccao implements Vetor{

    @Override
    public void fazerCalculo() {
        System.out.println("Calculo da Interseccao");
    }
    
}
