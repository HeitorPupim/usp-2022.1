public interface Vetor {
    
    public void fazerCalculo();
}