public class VetorDiferenca implements Vetor{

    @Override
    public void fazerCalculo() {
        System.out.println("Calculo da Diferenca");
        
    }
    
}
