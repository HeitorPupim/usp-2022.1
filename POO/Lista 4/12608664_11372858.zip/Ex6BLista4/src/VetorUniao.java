public class VetorUniao implements Vetor {

    @Override
    public void fazerCalculo() {
        System.out.println("Calculo da Uniao");
        
    }
    
}
