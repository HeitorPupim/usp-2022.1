public class Calcula {
    private int num;

    public Calcula(int num){
        this.num = num;
    }

    public int getNum(){
        return num;
    }
}
